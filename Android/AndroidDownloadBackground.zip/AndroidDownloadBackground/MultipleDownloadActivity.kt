package com.hybroad.wnyphone.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hybroad.wnyphone.R
import com.hybroad.wnyphone.adapter.MultipleDownloadAdapter
import com.hybroad.wnyphone.adapter.StorageVideoRecyclerviewAdapter
import com.hybroad.wnyphone.utils.MultipleDownloadProgress
import java.io.Serializable


class MultipleDownloadActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_multiple_download)

        val _fromIntent : ArrayList<DownloadStructure> = intent.extras?.get("download") as ArrayList<DownloadStructure>

//        _fromIntent.map { downloadStructure ->
//            MultipleDownloadProgress.let {
//                it.hashMap.put(it.id, downloadStructure)
//                it.id ++
//            }
//        }

        // make ArrayList<DownloadStructure> a functor! by implement fmap!
        fun <A> ArrayList<A>.functorMap(f: (A) -> String) = this.map { a ->
            f(a)
        }


        val _tmp = arrayListOf<DownloadStructure>()
        if (MultipleDownloadProgress.list.isEmpty()) MultipleDownloadProgress.list = _fromIntent
        else {
            _fromIntent.map { a ->
                if (MultipleDownloadProgress.list.functorMap { it.link }.contains(a.link).not())
                    _tmp.add(a)
            }
        }

        MultipleDownloadProgress.list.addAll(_tmp)

        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)

//        val adapter = MultipleDownloadAdapter(this,_fromIntent)
        val adapter = MultipleDownloadAdapter(this)
        recyclerView.setAdapter(adapter)
        adapter.notifyDataSetChanged()

        findViewById<Button>(R.id.back_button).setOnClickListener {
            this.finish()
        }
    }
}

data class DownloadStructure(val fileName: String, val link: String, var percent: Int = 0):Serializable