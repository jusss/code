package com.hybroad.wnyphone.adapter

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.hybroad.wnyphone.R
import com.hybroad.wnyphone.activity.DownloadStructure
import com.hybroad.wnyphone.activity.UpdateDownloadUi
import com.hybroad.wnyphone.activity.VideoStructure
import com.hybroad.wnyphone.utils.Generics.Companion.updateUIScope
import com.hybroad.wnyphone.utils.MultipleDownloadProgress
import com.hybroad.wnyphone.utils.RemoteList
import com.hybroad.wnyphone.video.VideoActivity
import kotlinx.coroutines.*
import org.joda.time.DateTime
import org.joda.time.DateTimeZone

//class MultipleDownloadAdapter (val context: Context, val _dataSource:  ArrayList<DownloadStructure>):
class MultipleDownloadAdapter (val context: Context):
    RecyclerView.Adapter<MultipleDownloadAdapter.ViewHolder>(){

    companion object {
        lateinit var dataSource: ArrayList<DownloadStructure>
    }

    init {
        dataSource = MultipleDownloadProgress.list
    }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val  fileName: TextView
        val progressBar: ProgressBar
        val remoteList : RemoteList
        init {
            // Define click listener for the ViewHolder's View.
            fileName = view.findViewById(R.id.fileName)
            progressBar = view.findViewById(R.id.progressBar)
            remoteList = RemoteList()
        }
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.activity_multiple_download_item, viewGroup, false)
        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

        // Get element from your dataset at this position and replace the
        // contents of the view with that element
        println("this is viewholder position $position")

        viewHolder.fileName.text = MultipleDownloadProgress.list[position].fileName
        updateUIScope.launch {
            async (Dispatchers.IO) {
                if (MultipleDownloadProgress.list[position].percent == 0)
                viewHolder.remoteList.download(
                    MultipleDownloadProgress.list[position].fileName,
                    MultipleDownloadProgress.list[position].link,
                    position
                )
            }
            async (Dispatchers.Main) {
                while (MultipleDownloadProgress.list[position].percent < 100) {
                    viewHolder.progressBar.setProgress(MultipleDownloadProgress.list[position].percent)
                    delay(100)
                }
                viewHolder.progressBar.setProgress(MultipleDownloadProgress.list[position].percent)
            }

        }
    }

    // Return the size of your dataset (invoked by the layout manager)
//    override fun getItemCount() = dataSet.size
    override fun getItemCount(): Int = dataSource.size
}



