package com.hybroad.wnyphone.utils

import com.hybroad.wnyphone.activity.DownloadStructure

class MultipleDownloadProgress {
    companion object {
        var id = 0
        var list : ArrayList<DownloadStructure> = arrayListOf()
        val hashMap = mutableMapOf<Int, DownloadStructure>()
    }
}