package com.hybroad.wnyphone.utils

import android.net.Uri
import android.os.Environment
import android.widget.ProgressBar
import com.google.gson.GsonBuilder
import com.hybroad.wnyphone.activity.DownloadStructure
import com.hybroad.wnyphone.activity.UpdateDownloadUi
import com.hybroad.wnyphone.activity.UpdateUploadUi
import com.hybroad.wnyphone.activity.VideoStructure
import com.hybroad.wnyphone.jtm.JTM
import io.ktor.client.HttpClient
import io.ktor.client.call.receive
import io.ktor.client.engine.cio.CIO
import io.ktor.client.request.delete
import io.ktor.client.request.get
import io.ktor.client.request.put
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.HttpStatement
import io.ktor.http.content.OutgoingContent
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.ByteWriteChannel
import io.ktor.utils.io.close
import io.ktor.utils.io.jvm.javaio.copyTo
import io.ktor.utils.io.jvm.javaio.toInputStream
import kotlinx.coroutines.*
import java.io.*

class RemoteList {
    // ADDR SET IN HERE! REMOTELIST TAKE A ADDR PARAMETER TO INITIALIZED!

    val updateUI = Job()
    val updateUIScope = CoroutineScope(Dispatchers.Main + updateUI)


    val httpClient = HttpClient(CIO) {
        followRedirects = false
    //        engine {
//            this@HttpClient.expectSuccess = false
//        }
//        followRedirects = false
//        install(HttpRedirect)
//        install(JsonFeature){
//            serializer = GsonSerializer()
//        }
    }
    suspend fun getContent(addr: String): JTM {
        val result = httpClient.get<String>(addr)
        val gson = GsonBuilder().create()
        print("json result $result")
        val objectList = gson.fromJson(result, JTM::class.java)
        return objectList
    }

    suspend fun delete(addr: String){
        println("delete files: $addr")
        val result = httpClient.delete<String>(addr)

        println(result)
    }

    suspend fun rename(addr: String){
        println("rename file: $addr")
        val result = httpClient.put<String>(addr)
        println("rename result: $result")
    }

    suspend fun createDirecotry(addr: String){
        val result = httpClient.put<String>(addr)
        println("create dir $result")
    }

    suspend fun getDownloadAddr(addr: String): String? {
        val _result = httpClient.get<HttpResponse>(addr)
        println("this is get download addr $_result")
        return _result.headers["LOCATION"]
        }

    suspend fun getFile(name: String, addr: String, invalid_count: Int, updateDownloadUi: UpdateDownloadUi) {
        println("before 1")
        val filePath = Environment.getExternalStorageDirectory().path + "/wnyphone/" + name
        val checkDir = Environment.getExternalStorageDirectory().path + "/wnyphone/"
        if (!File(checkDir).exists()) {
            File(checkDir).mkdir()
        }
        if (File(filePath).exists()) {
            File(filePath).delete()
        }

        val file = File(filePath)
        val fos = FileOutputStream(file)

        val client = HttpClient(CIO) {
            followRedirects = false
        }
        val _result = client.get<HttpResponse>(addr)
//        val readInputStream = client.get<InputStream>(_result.headers["LOCATION"]?:"")
        client.get<HttpStatement>(_result.headers["LOCATION"]
                ?: "").execute { response: HttpResponse ->
            // Response is not downloaded here.
            val channel = response.receive<ByteReadChannel>()
            val count = response.headers["Content-Length"]?.toInt()?:1
            println("this is the length $count")
            val readInputStream = channel.toInputStream()
            val buffer = ByteArray(1024)
            var len: Int
            var total = 0
            var percent = 0.00
            while (((readInputStream.read(buffer)).also { len = it }) != -1) {
                percent = (total.toDouble() / count.toDouble()) * 100
                updateDownloadUi.updateProgress(percent.toInt())
                fos.write(buffer, 0, len)
                total += len
                println("this is total $total , this is count $count , this is percent $percent")
            }
            fos.close()
            readInputStream.close()
            updateDownloadUi.activityFinish()
        }
    }

//                val buffer = ByteArray(1024)
//                var len: Int
//                var total = 0
//                var percent = 0.00

//                while (((readInputStream.read(buffer)).also { len = it }) != -1) {
//                    percent = (total.toDouble() / count.toDouble()) * 100
//                    updateDownloadUi.updateProgress(percent.toInt())
//                    fos.write(buffer, 0, len)
//                    fos.flush()
//                    total += len
//                    println("this is total $total , this is count $count , this is percent $percent")
//                }
//                fos.close()
//                readInputStream.close()
//               updateDownloadUi.activityFinish()
//    }



    suspend fun uploadFile(addr: String, uri: Uri, updateUi: UpdateUploadUi) {
        val output = httpClient.put<HttpResponse>(addr)
        println("this is upload test ${output.headers["Location"]}")
        val realUrl = output.headers["Location"]?:""
        val readInputStream = updateUi.getInputStream(uri)?:File("").inputStream()
        val count = updateUi.length(uri)
        val result = httpClient.put<ByteWriteChannel>(realUrl) {
            body = StreamContent(readInputStream, count, updateUi)
        }
    }

    suspend fun download(name: String, addr: String, position: Int) {
//        val id = MultipleDownloadProgress.id
//        MultipleDownloadProgress.id ++
//        MultipleDownloadProgress.hashMap.put(id, DownloadStructure(name,addr,0))
        val filePath = Environment.getExternalStorageDirectory().path + "/wnyphone/" + name
        val checkDir = Environment.getExternalStorageDirectory().path + "/wnyphone/"
        if (!File(checkDir).exists()) {
            File(checkDir).mkdir()
        }
        if (File(filePath).exists()) {
            File(filePath).delete()
        }

        val file = File(filePath)
        val fos = FileOutputStream(file)

        val client = HttpClient(CIO) {
            followRedirects = false
        }
        val _result = client.get<HttpResponse>(addr)
//        val readInputStream = client.get<InputStream>(_result.headers["LOCATION"]?:"")
        client.get<HttpStatement>(_result.headers["LOCATION"]
            ?: "").execute { response: HttpResponse ->
            // Response is not downloaded here.
            val channel = response.receive<ByteReadChannel>()
            val count = response.headers["Content-Length"]?.toLong()?:1
            println("this is the length $count")
            val readInputStream = channel.toInputStream()
            val buffer = ByteArray(1024)
            var len: Int
            var total = 0
            var percent = 0.00
            while (((readInputStream.read(buffer)).also { len = it }) != -1) {
                percent = (total.toDouble() / count.toDouble()) * 100
//                updateDownloadUi.setProgress(percent.toInt())
//                MultipleDownloadProgress.hashMap.get(id)?.percent = percent.toInt()
                MultipleDownloadProgress.list[position].percent = percent.toInt()
//                print("update percent: ")
//                println(MultipleDownloadProgress.hashMap.get(id)?.percent)
                fos.write(buffer, 0, len)
                total += len
                println("this is total $total , this is count $count , this is percent $percent")
            }
            fos.close()
            readInputStream.close()
            MultipleDownloadProgress.list[position].percent = 100
//            updateDownloadUi.activityFinish()
        }
    }
}




//        val swapStream = ByteArrayOutputStream()
//        val buff = ByteArray(1024)
//        var rc = 0
//        while (`readInputStream`.read(buff, 0, 1024).also({ rc = it }) > 0) {
//            swapStream.write(buff, 0, rc)
//            swapStream.flush()
//            total = total + rc
//            percent = (total.toDouble() / count.toDouble()) * 100
////            println("this is total $total , this is count $count , this is percent $percent")
//            updateDownloadUi.updateProgress(percent.toInt())
//        }
//        val in2b = swapStream.toByteArray()
//        fos.write(in2b)
//        fos.flush()
//        fos.close()
//        readInputStream.close()

//        while (true) {
//            len = readInputStream.read(buffer)
//            if (len != -1) {
//                fos.write(buffer.sliceArray(0 until len))
//                fos.flush()
//                total = total + len
//                percent = (total / count ) * 100
//                println("this is toatl $total , this is count $count , this is percent $percent")
//                updateDownloadUi.updateProgress(percent)
////                println("this is count $count")
//            } else {
//                break
//            }
//        }
//
//        fos.close()
//        activity.finish()

class StreamContent(private val inputStream: InputStream, val total: Long, val updateUi: UpdateUploadUi): OutgoingContent.WriteChannelContent() {
    override suspend fun writeTo(channel: ByteWriteChannel) {
        val readChannel = inputStream
        var copiedBytes: Long
        var count : Long = 0
        var percent = 0.00
        do {
            copiedBytes = readChannel.copyTo(channel, 1024)
            count =  count + copiedBytes
            percent = (count.toDouble() / total.toDouble()) * 100
            updateUi.updateProgress(percent.toInt())
            println("reading files now! count is $count")
            println("count is $count, total is $total, percent is $percent")
        } while (copiedBytes > 0)

        readChannel.close()
        channel.flush()
        channel.close()
    }
    override val contentLength: Long = total
}
