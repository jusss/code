package com.hybroad.wnyphone.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationItemView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.hybroad.wnyphone.*
import com.hybroad.wnyphone.utils.Generics.Companion.updateUIScope
import com.hybroad.wnyphone.adapter.StorageVideoRecyclerviewAdapter
import com.hybroad.wnyphone.storage.SolrTools.Companion.search
import com.hybroad.wnyphone.utils.*
import com.wuhenzhizao.titlebar.widget.CommonTitleBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.Serializable

class StorageVideoActivity :  AppCompatActivity() {
    lateinit var searchView: SearchView
    lateinit var adapter: StorageVideoRecyclerviewAdapter
    lateinit var recyclerView: RecyclerView
    var _list = arrayListOf<VideoStructure>()
    var switch = true

    val rl = RemoteList()
    val listOp = "?op=LISTSTATUS"
    val downloadOp = "?op=OPEN"
    val deleteOp = "?op=DELETE"
    val deleteDirOp = "?op=DELETE&recursive=true"
    val uploadOp = "?op=CREATE"
    val createDirOp = "?op=MKDIRS"
    val renameOp = "?op=RENAME&destination=/"
    var pathList = mutableListOf<String>()
    // endWith /, click listview item will append, click previous button will pop up
    fun currentDirectory(): String = pathList.reduce { p, n -> p + n }
    private val handler: Handler = object : Handler() {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            when (msg.what) {
                MemoActivityNew.START_LISTEN -> {
                    val query = msg.obj as String
                    ServiceController.startWakeUp()
                    val __list = arrayListOf<VideoStructure>()
                    if (_list.map { it.name.contains(query) }.reduce { acc, b -> acc || b  }.not())
                        Toast.makeText(this@StorageVideoActivity," $query not found",Toast.LENGTH_LONG).show()
                    else {
                        _list.map {
                            if (it.name.contains(query)) __list.add(it)
                        }
                        adapter = StorageVideoRecyclerviewAdapter(this@StorageVideoActivity,__list)
                        recyclerView.setAdapter(adapter)
                        adapter.notifyDataSetChanged()
                        switch = false
                        searchView.isIconified = false
                        searchView.setQuery(query,false)
                        searchView.clearFocus()
                    }
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 111 && resultCode == RESULT_OK) {
            val selectedFileUri =
                    data?.data ?: Uri.EMPTY //The uri with the location of the file
            val filePath = selectedFileUri.toString()

            val fileNameL = if (filePath.contains("/storage/emulated")) {
                filePath
            } else {
                FileUtils.getPath(this, selectedFileUri) ?: filePath
            }
            val fileName = if (fileNameL.contains("%2F")) {
                fileNameL.split("%2F").last()
            } else {
                fileNameL.split("/").last()
            }

            println("--selected file uri: $selectedFileUri")
            println("--upload file name: $fileName")

            val pictureList = listOf<String>(".mp4", ".mov", ".mkv")
            val isSupportPicture =
                    { x: String -> pictureList.map { x.endsWith(it) } }
            if (isSupportPicture(fileName).reduce { acc, b -> acc || b }.not()) {
                Toast.makeText(this@StorageVideoActivity, "当前路径只能上传视频", Toast.LENGTH_LONG).show()
            }
            else {
                val _remoteFileNameForUploadMatch = mutableListOf<String>()
                updateUIScope.launch {
                    withContext(Dispatchers.IO) {
                        val msg = rl.getContent(VPNAddr.baseUrl + currentDirectory() + listOp)
                        msg.fileStatuses.fileStatus.map { _remoteFileNameForUploadMatch.add(it.pathSuffix) }
                        println("--remote file name list for upload matching: $_remoteFileNameForUploadMatch")
                    }
                    if (_remoteFileNameForUploadMatch.contains(fileName)) {
                        Toast.makeText(this@StorageVideoActivity, "该文件已上传", Toast.LENGTH_LONG).show()
                    } else {
                        val addr = VPNAddr.baseUrl + currentDirectory() + fileName + uploadOp
                        val _forDownload =
                                arrayListOf<String>(fileName, addr, selectedFileUri.toString())
                        val intent = Intent(this@StorageVideoActivity, UploadActivity::class.java)
                        intent.putExtra("fileList", _forDownload)

                        // GET INTO UPLOAD ACTIVITY!
                        startActivity(intent)
//                        delay(20000)
//                    refreshUI(VPNAddr.baseUrl + currentDirectory() + listOp)
//                        rl.uploadFile(addr, selectedFileUri, this@MainActivity)
                        //refresh and search function with multipl search
//                        PictureAddrCache.result = arrayListOf<NaP<String,ArrayList<String>>>()
//                        refreshUI(this@PictureActivity, 0)
                    }
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_storage_video)
        val mainThis = this

        pathList.add("/webhdfs/v1/album/")
        pathList.add("")
        val titleBar = findViewById<CommonTitleBar>(R.id.titlebar)
        titleBar.rightCustomView.setOnClickListener {

            val intent = Intent().setType("*/*").setAction(Intent.ACTION_GET_CONTENT)
            startActivityForResult(Intent.createChooser(intent, "Select a file"), 111)
        }

        findViewById<ImageView>(R.id.back_image).setOnClickListener {

            if (switch) {
                this.finish()
            }
            else {
                refreshUI("file_name:*mp4")
                switch = true
                searchView.setQuery("",false)
                searchView.setFocusable(false);
                recyclerView.requestFocus()
            }
        }
        recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        searchView = findViewById<SearchView>(R.id.search)
        searchView.setIconifiedByDefault(true);
//        searchView.setFocusable(true);
//        searchView.setIconified(false);
//        searchView.requestFocusFromTouch();

        refreshUI("file_name:*mp4")

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                        val __list = arrayListOf<VideoStructure>()
                        if (_list.map { it.name.contains(query) }.reduce { acc, b -> acc || b  }.not())
                            Toast.makeText(this@StorageVideoActivity,"$query not found",Toast.LENGTH_LONG).show()
                        else {
                            _list.map {
                                if (it.name.contains(query)) __list.add(it)
                            }
                            adapter = StorageVideoRecyclerviewAdapter(this@StorageVideoActivity,__list)
                            recyclerView.setAdapter(adapter)
                            adapter.notifyDataSetChanged()
                            switch = false
                            searchView.setFocusable(false);
                            recyclerView.requestFocus()
                        }
                return false
            }
            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })

        findViewById<ImageView>(R.id.button777).setOnClickListener {
            ServiceController.stopWakeUp()
            //开启监听
            IatTest(mainThis).startListen(mainThis, handler, 0)
        }

        // download in bottom navigation bar
        findViewById<BottomNavigationItemView>(R.id.item4).setOnClickListener {
            val _result  : ArrayList<DownloadStructure> = arrayListOf()
            StorageVideoRecyclerviewAdapter.dataSource.map {
                if (it.choosen) _result.add(DownloadStructure(it.name, it.link))
            }
            _result.map {
                println(it.link)
            }
            val intent = Intent(mainThis, MultipleDownloadActivity::class.java)
            intent.putExtra("download", _result as Serializable)
            startActivity(intent)
        }
    }

    fun refreshUI(query: String){
        _list = arrayListOf()
        updateUIScope.launch {
            withContext(Dispatchers.IO) {
                val result = search(query)
//                val result = search("*:*")
                result.response.docs.map {
                    _list.add(VideoStructure(it.thumbnail, it.file_name, it.duration, it.file_size,
                            it.file_date_auto, VPNAddr.baseUrl + it.download_link
                    ))
                }
            }
            withContext(Dispatchers.Main) {
                println("this is video list $_list")
                val _size = _list.size
                println("video list size is $_size")
                adapter = StorageVideoRecyclerviewAdapter(this@StorageVideoActivity,_list)
                recyclerView.setAdapter(adapter)
                adapter.notifyDataSetChanged()
            }
        }
    }
}
data class VideoStructure (val thumbnail: String, val name: String, val duration: Long, val size: Long, val date: Long, val link: String, var choosen : Boolean = false)
