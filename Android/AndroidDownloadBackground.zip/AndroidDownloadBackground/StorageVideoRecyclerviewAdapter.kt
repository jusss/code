package com.hybroad.wnyphone.adapter

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.hybroad.wnyphone.R
import com.hybroad.wnyphone.activity.VideoStructure
import com.hybroad.wnyphone.video.VideoActivity
import org.joda.time.DateTime
import org.joda.time.DateTimeZone

class StorageVideoRecyclerviewAdapter (val context: Context, val _dataSource:  ArrayList<VideoStructure>):
        RecyclerView.Adapter<StorageVideoRecyclerviewAdapter.ViewHolder>() {

    companion object {
        lateinit var dataSource: ArrayList<VideoStructure>
    }

    init {
        dataSource = _dataSource
    }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val image: ImageView
        val  name: TextView
        val  duration: TextView
        val  size: TextView
        val  date: TextView
        val checkboxImage: ImageView
        init {
            // Define click listener for the ViewHolder's View.
            image = view.findViewById(R.id.image)
            name = view.findViewById(R.id.name)
            duration = view.findViewById(R.id.duration)
            size = view.findViewById(R.id.size)
            date = view.findViewById(R.id.date)
            checkboxImage = view.findViewById(R.id.checkbox_image)
        }
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        val view = LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.activity_storage_video_item, viewGroup, false)

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

        // Get element from your dataset at this position and replace the
        // contents of the view with that element
        val _image = Base64.decode(dataSource[position].thumbnail, Base64.DEFAULT)

        viewHolder.image.setImageBitmap(BitmapFactory.decodeByteArray(_image,0,_image.size))
        viewHolder.name.text = dataSource[position].name
        viewHolder.date.text = DateTime(dataSource[position].date * 1000, DateTimeZone.UTC).toString().replace("T"," ").split(".").get(0)
        viewHolder.duration.text = dataSource[position].duration.toString() + "秒"
        val _t = (dataSource[position].size / 1024.0 / 1024)
        viewHolder.size.text = String.format("%.1f",_t)+ " MB"


        viewHolder.checkboxImage.setOnClickListener {
            dataSource[position].choosen = dataSource[position].choosen.not()
            if (dataSource[position].choosen)
                viewHolder.checkboxImage.setImageResource(R.mipmap.selected_icon)
            else
                viewHolder.checkboxImage.setImageResource(R.mipmap.no_selected_icon)
        }

        // use itemView bind on whole item, viewHolder.image.setOnClickListener bind on image only
        viewHolder.itemView.setOnClickListener {
            val _intent = Intent(context, VideoActivity::class.java)
            _intent.putExtra("url", dataSource[position].link)
            context.startActivity(_intent) //adapter doesn't have startActivity, context has
        }

    }

    // Return the size of your dataset (invoked by the layout manager)
//    override fun getItemCount() = dataSet.size
    override fun getItemCount(): Int = dataSource.size
}



