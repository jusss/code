package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.sun.k2p.Robot;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new Thread()
        {
            public void run() {
                Robot m = new Robot("192.168.1.147", 50017);
                m.sendToRobot("hello");
                m.close();
            }
        }.start();
    }
}
