package com.example.circleprogressbar;

import android.app.Application;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class AppGlobals {


    public static final String IS_FIRST_START = "is_first_start";
    public static final String MASTER_ACCOUNT = "master_account";
    public static final String MASTER_PASSWORD = "master_password";

    private static Application application;

    public static Application getApplication(){
        if(application==null){
            try {
                Method method = Class.forName("android.app.ActivityThread").getDeclaredMethod("currentApplication");
                application = (Application) method.invoke(null, (Object[]) null);
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
        return application;
    }

}
