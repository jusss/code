package com.example.remotefilemanager

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.GsonBuilder
import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO
import io.ktor.client.features.json.GsonSerializer
import io.ktor.client.features.json.JsonFeature
import io.ktor.client.request.get
import kotlinx.coroutines.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val rl = RemoteList("http://49.5.6.84:9870/webhdfs/v1/?op=LISTSTATUS")
        var fileList = mutableListOf<FileStructure>()
        var fileNameList = mutableListOf<String>()
        var updateUI = Job()
        val updateUIScope = CoroutineScope(Dispatchers.Main + updateUI)
        val mainThis = this
        val listView = findViewById<ListView>(R.id.mobile_list)
        val adapter = ArrayAdapter(mainThis, R.layout.activity_listview,fileNameList )
        listView.setAdapter(adapter)
        updateUIScope.launch {
            withContext(Dispatchers.IO){
                val msg = rl.getContent()
                val gson = GsonBuilder().create()
                val object1 = gson.fromJson(msg, JTM::class.java)
                object1.fileStatuses.fileStatus.map { fileList.add(FileStructure(it.pathSuffix,it.accessTime,it.blockSize)) }
                println(fileList.get(0).name)
                println(fileList.get(0).time)
                println(fileList.get(0).size)
                object1.fileStatuses.fileStatus.map { fileNameList.add(it.pathSuffix) }
                println(fileNameList)
                withContext(Dispatchers.Main){
                    adapter.notifyDataSetChanged()
                }
            }
        }
    }
}

class FileStructure(val fileName:String, val epochTime: Long, val blockSize: Int){
        val name = fileName

        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val date = java.util.Date(epochTime )
        val time = sdf.format(date)

        val size1 = blockSize / 1024 / 1024
        val size = if (size1 > 1024) (size1 / 1024).toString() + "M" else size1.toString() + "K"
}

class RemoteList (val addr: String) {
    suspend fun getContent(): String {
        val httpClient = HttpClient(CIO){
            install(JsonFeature){
                serializer = GsonSerializer()
            }
        }
        val result = httpClient.get<String>(addr)
        println(result)
        return result
    }
}
