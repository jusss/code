package com.example.listview2

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import java.time.DayOfWeek


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fileNameList = mutableListOf("a", "b", "3", "d")
        val listView = findViewById<ListView>(R.id.mobile_list)
        val adapter = FileAdapter(this, fileNameList)
//        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice,fileNameList )
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        listView.setAdapter(adapter)
        adapter.notifyDataSetChanged()





    }
}



