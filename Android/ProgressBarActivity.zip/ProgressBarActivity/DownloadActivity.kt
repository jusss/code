package com.example.progressbar

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*


class DownloadActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.download)

        findViewById<Button>(R.id.button2).setOnClickListener {
            this.finish()
        }

        val updateUI = Job()
        val updateUIScope = CoroutineScope(Dispatchers.Main + updateUI)
        val progress = findViewById<ProgressBar>(R.id.progressBar)
        updateUIScope.launch {
            withContext(Dispatchers.IO) {
                progress.setProgress(0)
                delay(2000)
                progress.incrementProgressBy(10)
                delay(2000)
                progress.incrementProgressBy(10)
                delay(2000)
                progress.incrementProgressBy(10)
                delay(2000)
            }
        }

    }
}
