package com.example.tts6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.util.Log;

import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechUtility;

import static android.content.ContentValues.TAG;
import static android.speech.tts.TextToSpeech.*;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechSynthesizer;
import com.iflytek.cloud.SynthesizerListener;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //SpeechUtility.createUtility(this, SpeechConstant.APPID + "=5f6b0669");
        SpeechUtility.createUtility(getApplicationContext(), "appid=5f6b0669");
        AudioUtils.getInstance().init(getApplicationContext());
        AudioUtils.getInstance().speakText("北京今天的天气怎么样呀");
        //AudioUtils tts = new AudioUtils();
        //tts.init(this);
        //tts.speakText("这个手机比较新,哈哈哈");
    }
}

