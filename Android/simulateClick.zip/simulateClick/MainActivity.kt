package com.example.imitation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import java.io.DataOutputStream

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        adbInput("input keyevent 3")
        Thread.sleep(1000)
        //adbInput("am start -n com.termux/com.termux.app.TermuxActivity")
        adbInput("am start -n com.example.toast/com.example.toast.MainActivity")
        Thread.sleep(1000)
        adbInput("input tap 787 681")
        Thread.sleep(3000)
        adbInput("input tap 787 681")


    }

    fun adbInput (context: String){
        try {
            val process = Runtime.getRuntime().exec("su")
            val outputStream = process.outputStream
            val dataOutputStream = DataOutputStream(outputStream)
            dataOutputStream.writeBytes(context)
            dataOutputStream.flush()
            dataOutputStream.close()
            outputStream.close()
        } catch (exception: Throwable){
            exception.printStackTrace()
        }
    }

}