package com.example.toast

import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val ws = findViewById<Button>(R.id.connectButton)
        ws.setOnClickListener {
            val toast = Toast.makeText(this, "hello", Toast.LENGTH_SHORT)
            toast.setGravity(Gravity.CENTER,0,0)
            toast.show()
        }


        ws.setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        val x = event.getX().toString()
                        val y = event.getY().toString()
                        val vx = ws.left.toString()
                        val vy = ws.right.toString()
                        val p = vx + " and " + vy
                        println(p)
                    }
                    MotionEvent.ACTION_UP -> {
                    }
                }
                return v?.onTouchEvent(event) ?: true
            }
        })



    }
}