module Narcissistic where
import Data.List
import Data.Semigroup

narcissistic :: Integral n => n -> Bool
narcissistic n = 
  let i = (f4 n) in foldl1 (+) (fmap (^(length i) i)) == n

-- f3 123 = [3,2,1]
f3 x = if (div x 10) == 0 then [x]
    else
        x - (div x 10) * 10 : [] <> f3 (div x 10)

-- f4 123 = [1,2,3]
f4 x = reverse $ f3 x

main = print $ narcissistic 1000
