module Codewars.Parentheses where

validParentheses :: String -> Bool
validParentheses = 
if Data.List.null (filter (>0) (fmap sum (inits (fmap f (fst (partition (`elem` "()") x))))))
then True
else False

f '(' = -1
f ')' = 1
