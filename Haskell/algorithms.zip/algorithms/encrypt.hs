module AlternateSplit.JorgeVS.Kata where
import Data.List
-- import Data.Semigroup

encrypt :: String -> Int -> String
encrypt x n =
 if (x == "") then ""
 else if n <= 0 then x
 else encrypt (f2 x) (n - 1)

decrypt :: String -> Int -> String
decrypt x n =
 if x == "" then ""
 else if n <= 0 then x
 else decrypt (f2r x) (n - 1)


-- just [1,2,3,4,5,6] to [2,4,6,1,3,5]
-- "This is a test!", 2 -> "hsi  etTi sats!" -> "s eT ashi tist!"
-- f2 [0,1,2,3,4] == [1,3,0,2,4]
ttl (a,b) = [a,b]
f2r x = (mconcat . fmap reverse . transpose . ttl . splitAt (div (length x) 2)) x

-- f x = (fmap (x !!) [1,3..(length x)]) (<>) (fmap (x !!) [0,2..(length x)])
f2 x = map snd . uncurry (++) . partition (odd . fst) . zip [0..] $ x
-- f3 x = (mconcat . transpose . chunksOf 2) x

-- main = print $ flip decrypt 3 $ encrypt "This is a test!" 3
msg = encrypt "This is a test!" 5

main = print $ fmap (decrypt msg) [0..10]
