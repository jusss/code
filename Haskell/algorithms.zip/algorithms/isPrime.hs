module IsPrime where
import Data.List
import Data.Semigroup

isPrime :: Integer -> Bool
isPrime 0 = False
isPrime 1 = False
isPrime 2 = True
isPrime 3 = True

isPrime x = if x < 0 then 
  False
  else
  let y = floor (sqrt (fromIntegral x) :: Double) in (0 `notElem` (fmap (mod x) [2..y]))


-- f3 123 = [3,2,1]
f3 x = if (div x 10) == 0 then [x]
    else
        x - (div x 10) * 10 : [] <> f3 (div x 10)

-- f4 123 = [1,2,3]
f4 x = reverse $ f3 x

main = print $ isPrime 1212324

--  f x = 0 `notElem` (fmap (mod x) [2..(x-1)])
