module RomanNumerals where
import Data.Map
import Data.List
import Data.Semigroup

solution :: Integer -> String
solution n = foldl1 (<>) (fmap (romanNum !) ((f5 . f4) n))
-- [100,20,3] -> [(100,"C"), (20,"XX"), (3,"III")] -> "CXXIII"
-- ["C","XX","III"] -> "CXXIII"

-- f5 [1,2,3] = [100,20,3]
f5 x = if (Data.List.null x) then [] else ((head x) * (10 ^ ((length x) - 1)) :[]) <> f5 (tail x)

-- f n = romanNum !! $ head (f4 n) * (10^ (length n))
 

-- f3 123 = [3,2,1]
f3 x = if (div x 10) == 0 then [x]
    else
        x - (div x 10) * 10 : [] <> f3 (div x 10)

-- f4 123 = [1,2,3]
f4 x = reverse (f3 x)

romanNum = fromList [(0,""),(3000, "MMM"),(2000,"MM"),(1000,"M"),(900, "CM"),(800, "DCCC"),(700, "DCC"),(600, "DC"),(500, "D"),(100, "C"),(200, "CC"),(300, "CCC"),(400, "CD"),(50, "L"),(60, "LX"),(70, "LXX"),(80, "LXXX"),(90, "XC"),(10, "X"),(20, "XX"),(30, "XXX"),(40, "XL"),(9, "IX"),(8, "VIII"),(7, "VII"),(6, "VI"),(5, "V"),(4, "IV"),(3, "III"),(2, "II"),(1, "I")]

main = print $ solution 1990
