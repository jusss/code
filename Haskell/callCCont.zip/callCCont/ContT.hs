import Control.Monad.Trans.Cont

--c1 :: () -> ContT () IO a -- it needs String -> IO ()
--c2 :: a -> ContT () IO String
c3 :: () -> ContT () IO String
-- c3 = c1 >=> c2
c3 () = ContT $ \k -> do
    k "hello, friend"

t :: IO ()
t = runContT (c3 ()) (f :: String -> IO ()) 

f = print

main = t





