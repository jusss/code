## 0.4.0
* Remove unnecessary argument to `scottyTTLS` so that `scotty-tls` can build
  with `scotty-0.10` and up
