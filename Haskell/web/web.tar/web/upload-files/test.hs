import Data.String.Split (splitOn)

main = print $ splitOn "a" "ab"
