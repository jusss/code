package com.aldebaran.ks

import com.aldebaran.qi.Application
import com.aldebaran.qi.helper.EventCallback
import com.aldebaran.qi.helper.proxies.ALDialog
import com.aldebaran.qi.helper.proxies.ALMemory
import com.aldebaran.qi.CallError
import com.aldebaran.qi.helper.proxies.ALAudioDevice
import com.aldebaran.qi.helper.proxies.ALTextToSpeech

val recordingList = {
        x:ArrayList<String> ->
    for (i in 0..1000){
        x.add("/home/nao/java8/recording/$i.ogg")
    }
    x
}(arrayListOf())

var counter = 0

val exitDialog:(ALDialog,String,String) -> Unit = {
    a,b,c ->
        a.deactivateTopic(b)
        a.unloadTopic(b)
        a.unsubscribe(c)
}

val startRecording: (ALAudioDevice) -> Unit = {
    it.stopMicrophonesRecording()
    counter++
    it.startMicrophonesRecording(recordingList[counter])
}

val stopRecording:(ALAudioDevice) -> Unit = {
    it.stopMicrophonesRecording()
}

fun main(args: Array<String>) {
    println("AI")
    var asr:String
    var nlp:String
    val robotUrl = "tcp://nao.local:9559"
    val application = Application(args, robotUrl)
    application.start()
    val session = application.session()
    val dialog = ALDialog(session)
    val memory = ALMemory(session)
    val tts = ALTextToSpeech(session)
    tts.language = "Chinese"
    val audio = ALAudioDevice(session)
    dialog.setLanguage("Chinese")
    val topic = dialog.loadTopic("/home/nao/java8/dialog_mnc.top")
    dialog.subscribe("myModule")
    dialog.activateTopic(topic)
    println("begin")

    startRecording(audio)

    // Subscribe to FrontTactilTouched event,
    // create an EventCallback expecting a Float.
/*    memory.subscribeToEvent(
        "FrontTactilTouched",
        object : EventCallback<Float> {
            override fun onEvent(arg0: Float): Unit = if (arg0 > 0) exitDialog(
                dialog,topic,"myModule"
            ) else
                tts.say("ouch!")
        })*/

    memory.subscribeToEvent(
        "FrontTactilTouched",
        EventCallback {it:Float ->
            if (it>0 )
                memory.raiseEvent("_msg", "初始事件测试")
            //else tts.say("ouch!")
        }
    )

    memory.subscribeToEvent(
        "_exit",
        EventCallback {_:String ->
            exitDialog(dialog,topic,"myModule")
            stopRecording(audio)
        }
    )

    memory.subscribeToEvent(
        "_stop",
        EventCallback {
            _:String ->
            stopRecording(audio)
        }
    )

    memory.subscribeToEvent(
        "_start",
        EventCallback {
            _:String ->
            startRecording(audio)
        }
    )

    memory.subscribeToEvent(
        "_nus",
        EventCallback {
            _:String ->
            stopRecording(audio)
            println("counter is " + recordingList[counter])
            asr = mainASR(recordingList[counter])
            println("asr is $asr")
            nlp = mainNLP(asr)
            println("nlp is $nlp")
            //memory.raiseEvent("_msg", "我还不明白")
            memory.raiseEvent("_msg", nlp)
        }
    )

    application.run()
}
