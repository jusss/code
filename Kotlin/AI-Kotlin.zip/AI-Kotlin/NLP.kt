package com.aldebaran.ks

import com.google.gson.Gson
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

fun curlmd5(src:String):String{
    val md = MessageDigest.getInstance("MD5")
    val resultByte = md.digest(src.toByteArray(Charsets.UTF_8))
    return resultByte.joinToString("") {
        String.format("%02x", it).toUpperCase()
    }
}

fun get_params(question:String): String{
    val STRING_LENGTH = 10;
    val ALPHANUMERIC_REGEX = "[a-zA-Z0-9]+";
    val charPool: List<Char> = ('a'..'z') + ('A'..'Z') + ('0'..'9')
    val randomString = (1..STRING_LENGTH)
        .map { i -> kotlin.random.Random.nextInt(0, charPool.size) }
        .map(charPool::get)
        .joinToString("");
    val time_stamp = System.currentTimeMillis()/1000
    val app_key="URY2h67ATeRGJIRK"
    val paramsDict = mutableMapOf<String, String>()
    paramsDict["app_id"] = "2111117142"
    paramsDict["question"] = URLEncoder.encode(question, "UTF-8")
    paramsDict["time_stamp"] = time_stamp.toString()
    paramsDict["nonce_str"] = URLEncoder.encode(randomString, "UTF-8")
    paramsDict["session"] = "10000"
    var signBefore =""
    for (key in paramsDict.toSortedMap().keys){
        signBefore = signBefore + key + "=" + paramsDict[key] + "&"
    }
    var signB = signBefore
    signBefore = signBefore + "app_key=" + app_key
    //println(signBefore)
    paramsDict["sign"] = curlmd5(signBefore)
    signB = signB + "sign=" + paramsDict["sign"]
    //println("this is the signB $signB")
    return signB
    //return paramsDict
}
fun get_content(question: String):String{
    //val gson = GsonBuilder().create()
    val url = URL("https://api.ai.qq.com/fcgi-bin/nlp/nlp_textchat")
    //val url = URL("http://openapi.tuling123.com/openapi/api/v2")
    //val sendDataStr  = gson.toJson(get_params(question))
    //val sendDataStr = """{"question": "hello", 'nonce_str': 'iyhGnB0AkL', 'app_id': '2111117142', 'sign': 'AA354827F740CC9A0546F54E3A9AB06A', 'session': '10000', 'time_stamp': '1561651456'}"""
    //val sendDataStr = """{"reqType": 0, "perception": {"inputText": {"text": "hi"}, "inputImage": {"url": "imageUrl"}, "selfInfo": {"location": {"city": "北京", "province": "北京", "street": "信息路"}}}, "userInfo": {"apiKey": "79229c49d0014c68ab90b9282ebf7156", "userId": "360371"}}"""
    val sendDataStr = get_params(question)
    //val sendData = URLEncoder.encode(sendDataStr, "UTF-8");
    //println(sendDataStr)
    //println(sendData)
    val httpconn = url.openConnection()  as HttpURLConnection
    httpconn.requestMethod = "POST"
    httpconn.doOutput = true
    //httpconn.doInput=true
    httpconn.setRequestProperty("charset", "utf-8")
    //httpconn.setRequestProperty("Content-lenght", postData.size.toString())
    httpconn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
    try {
        val outputStream: DataOutputStream = DataOutputStream(httpconn.outputStream)
        outputStream.write(get_params(question).toByteArray(charset=Charsets.UTF_8))
        outputStream.flush()
    } catch (exception: Exception) {
        throw Exception("Exception while push the notification  $exception.message")
    }
    try {
        val reader: BufferedReader = BufferedReader(InputStreamReader(httpconn.inputStream, "UTF8"))
        //
        //
        //this is the bug, you forget to set encoding when reading it from server!
        //
        //
        var output = reader.readLine()
        var result = ""
        while (output != null){
            result += output
            output = reader.readLine()
        }
        //println(result)
        return result
    } catch (exception: Exception) {
        throw Exception("Exception while push the notification  $exception.message")
    }
}
data class recvMsg(val ret:String,
                   val msg:String,
                   val data:Map<String,String>)

fun mainNLP(question: String):String{
    val gson = Gson()
    //val a = get_content("北京今天的天气")
    val a = get_content(question)

    val map1 = gson.fromJson(a,recvMsg::class.java)
    println(a)
    val r:String? = map1.data["answer"]
    return  r?:"NothingInNLP"
}
