package com.aldebaran.ks

import com.google.gson.GsonBuilder
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.*

fun _curlmd5(src:String):String{
    val md = MessageDigest.getInstance("MD5")
    val resultByte = md.digest(src.toByteArray(Charsets.UTF_8))
    return resultByte.joinToString("") {
        String.format("%02x", it)
    }
}

fun getHeader(aue:String,engineType:String):Map<String,String>{
    val APPID = "x"
    val API_KEY = "x"
    val time_stamp = System.currentTimeMillis()/1000
    val curTime = time_stamp.toString()
    //val curTime = "1563961545"
    val paramBase64 = "x"
    val checkSum = _curlmd5(API_KEY + curTime + paramBase64)
    val header = mutableMapOf<String,String>()
    header["X-CurTime"] = curTime
    header["X-Param"] = paramBase64
    header["X-Appid"] = APPID
    header["X-CheckSum"] = checkSum
    header["Content-Type"] = "application/x-www-form-urlencoded; charset=utf-8"
    println(header)

    return header
}

fun getBody(filePath:String):String{
    val binFile =  File(filePath).inputStream().readBytes()
    val data =  Base64.getEncoder().encodeToString(binFile)
    return "audio=$data"
}
data class asrMsg(val data:String)
fun mainASR(filePath: String):String {
    val addr = "http://api.xfyun.cn/v1/service/v1/iat"
    val url = URL(addr)
    val gson = GsonBuilder().create()
    val httpconn = url.openConnection()  as HttpURLConnection
    httpconn.requestMethod = "POST"
    httpconn.doOutput = true
    val header = getHeader("raw","sms16k")
    header.forEach {
        k,v ->
        httpconn.setRequestProperty(k,v)
    }

    try {
        val outputStream: DataOutputStream = DataOutputStream(httpconn.outputStream)
        outputStream.write(
            getBody(filePath)
                .toByteArray(charset=Charsets.UTF_8))
        outputStream.flush()
    } catch (exception: Exception) {
        throw Exception("Exception while push the notification  $exception.message")
    }
    try {
        val reader: BufferedReader = BufferedReader(InputStreamReader(httpconn.inputStream, "UTF8"))
        //
        //
        //this is the bug, you forget to set encoding when reading it from server!
        //
        //
        var output = reader.readLine()
        var result = ""
        while (output != null){
            result += output
            output = reader.readLine()
        }
        println(result)
        val map2 = gson.fromJson(result,asrMsg::class.java)
        println(map2)
        val r:String? = map2.data
        println(r)
        return r?:"NothingInASR"
        //return result
    } catch (exception: Exception) {
        throw Exception("Exception while push the notification  $exception.message")
    }
}
















