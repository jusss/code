package com.example.k2p

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.net.Socket
import kotlin.concurrent.thread
import kotlinx.coroutines.*
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
       /* val ws = findViewById<TextView>(R.id.what2)*/

        /*ws.setOnClickListener {
            Thread(Runnable {
                val sock = Socket("192.168.31.204", 50009)
                sock.use {
                    it.outputStream.write(
                        "aha, it's from kotlin".toByteArray(
                            Charsets.UTF_8
                        )
                    )
                    it.outputStream.flush()
                    var aob = ByteArray(1024)
                    it.inputStream.read(aob)

                    this@MainActivity.runOnUiThread(java.lang.Runnable {
                        this.text1.text = aob.toString(Charsets.UTF_8)
                    })
                }
            }).start()

    }}*/

    fun updateUI(view: View){
        GlobalScope.launch {
            val showTextView = findViewById<TextView>(R.id.text1)
            val sock = Socket("192.168.31.204", 50007)
            sock.use {
                it.outputStream.write(
                    "aha, it's from kotlin".toByteArray(
                        Charsets.UTF_8
                    )
                )
                it.outputStream.flush()
                var aob = ByteArray(1024)
                it.inputStream.read(aob)
                withContext(Dispatchers.Main){
                    showTextView.text=aob.toString(Charsets.UTF_8)
                }
            }
        }
    }

    /*fun toastMe(view: View) {
        // val myToast = Toast.makeText(this, message, duration);
        val myToast = Toast.makeText(this, "Hello Toast!", Toast.LENGTH_SHORT)
        myToast.show()
    }

    //fun countMe (view: View) {
        // Get the text view
        //val showCountTextView = findViewById<TextView>(R.id.text1)
        // Display the new value in the text view.
        //showCountTextView.text= "now"
    //}

    fun connect(view: View){
        val showCountTextView = findViewById<TextView>(R.id.text1)

        val sock = Socket("192.168.31.204", 50009)
        sock.use {
            it.outputStream.write("aha, it's from kotlin".toByteArray(
                Charsets.UTF_8
            ))
            it.outputStream.flush()
            var aob = ByteArray(1024)
            it.inputStream.read(aob)
            showCountTextView.text= aob.toString(Charsets.UTF_8)
            //println(aob.toString(Charsets.UTF_8))
            it.inputStream.read(aob)
        }
       // showCountTextView.text="now"
    }

    fun connect2(view: View){

        val sock = Socket("192.168.31.204", 50009)
        sock.use {
            it.outputStream.write("aha, it's from kotlin".toByteArray(
                Charsets.UTF_8
            ))
            it.outputStream.flush()
            var aob = ByteArray(1024)
            it.inputStream.read(aob)


        }
        // showCountTextView.text="now"
    }

*/



}
