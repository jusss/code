import java.net.Socket
import java.net.ServerSocket

fun main(args: Array<String>) {
    val sock = Socket("127.0.0.1", 50007)
    sock.use {
        it.outputStream.write("aha, it's from kotlin".toByteArray(
            Charsets.UTF_8
        ))
        it.outputStream.flush()
        var aob = ByteArray(1024)
        it.inputStream.read(aob)
        println(aob.toString(Charsets.UTF_8))
    }
}