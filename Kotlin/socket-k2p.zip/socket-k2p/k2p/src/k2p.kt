import java.net.Socket

class Robot(addr:String, port:Int){
    val sock = Socket(addr, port)
    fun sendToRobot(msg:String): Boolean {
        sock.outputStream.write(msg.toByteArray(Charsets.UTF_8))
        sock.outputStream.flush()
        return true
    }
    fun recvFromRobot():String{
        var aob = ByteArray(1024)
        sock.inputStream.read(aob)
        println(aob.toString(Charsets.UTF_8))
        return aob.toString(Charsets.UTF_8)
    }
    fun close(){
        sock.close()
    }
}

fun main(){
    val a = Robot("127.0.0.1",50017)
    a.sendToRobot("3\n")
    a.sendToRobot("7")
}
// sock.use {} is like with statement in python, auto close file io or socket io
