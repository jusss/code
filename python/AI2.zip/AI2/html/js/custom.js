//f=(function(f){ 

function subscribe_event (event,to_do) {

    QiSession(function (session) {
	session.service("ALMemory").then(
	    function(a){a.subscriber(event).then(
		function(s){s.signal.connect(to_do)})})})};

function insert_data (k,v){

    QiSession(function (session) {
	session.service("ALMemory").then(
	    function(a){a.insertData(k,v)})})};

function get_data (event,to_do) {

    QiSession(function (session) {
	session.service("ALMemory").then(
	    function(a){a.getData(event).then(to_do)})})};

//    f["subscribe_event"]=subscribe_event;
//    f["insert_data"]=insert_data;
//    f["get_data"]=get_data;
//return f
//    
//}(window.f || {}))
//

//zz = (function(k,v) { return
//		      function(){ console.log(k);console.log(v)}})("a","b")
				  
