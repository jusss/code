import requests
import json
def saf():
    with open('d:/iflytek01.wav', 'rb') as f:
        while 1:
            data=f.read(1024)
            if not data:
                break
            yield data
 
headers = {
   'Transfer-Encoding': 'chunked',
    'Content-type': 'audio/wav; codecs=audio/pcm; samplerate=16000',
    'Ocp-Apim-Subscription-Key': 'a679a32de15246a1ae3d0b8f7418ac38',
    'Accept': 'application/json'    
}
 
response = requests.post('https://westus.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language=zh-CN', headers=headers, verify=False, data=saf()
                         )
 
print(response.content)
results=json.loads(response.content)
print(results)
