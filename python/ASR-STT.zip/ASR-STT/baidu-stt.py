"""
get the api key and secret key, then use the post method get the token
>>> r=requests.post('https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=GSq6R1NLtqo6Fujyu2Zqel9f&client_secret=CCEwY3ps58cTHbAuTWi5sfZIyGuU1R8z')
>>> r.content
b'{"access_token":"24.87e6e625e4a4d042269b6618e329db6a.2592000.1559026585.282335-16132137","session_key":"9mzdA51pwnMvldLAn6fPXfDF9toXRUwxiyTlUxyyYks34fsIRh4hfVxkfwsa77OEwFcG\\/UaHl35JX5vCGBhU0RzxzvK3Ww==","scope":"audio_voice_assistant_get brain_enhanced_asr audio_tts_post public brain_all_scope wise_adapt lebo_resource_base lightservice_public hetu_basic lightcms_map_poi kaidian_kaidian ApsMisTest_Test\\u6743\\u9650 vis-classify_flower lpq_\\u5f00\\u653e cop_helloScope ApsMis_fangdi_permission smartapp_snsapi_base iop_autocar oauth_tp_app smartapp_smart_game_openapi oauth_sessionkey smartapp_swanid_verify smartapp_opensource_openapi smartapp_opensource_recapi","refresh_token":"25.0fc16686a98b5bfda9fe08389cbb0aca.315360000.1871794585.282335-16132137","session_secret":"596a844a57cebc6a3f5996e94f38122c","expires_in":2592000}\n'

curl -i -X POST -H "Content-Type: audio/wav;rate=16000" "http://vop.baidu.com/server_api?dev_pid=1536&cuid=whateverelse&token=24.87e6e625e4a4d042269b6618e329db6a.2592000.1559026585.282335-16132137" --data-binary "@a.wav"
"""
