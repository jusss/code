import requests
import json
def saf():
    with open('0.ogg', 'rb') as f:
        while 1:
            data=f.read(1024)
            if not data:
                break
            yield data
 
headers = {
   'Transfer-Encoding': 'chunked',
   'Content-Type': 'audio/ogg; codecs:opus',
    'Ocp-Apim-Subscription-Key': 'a679a32de15246a1ae3d0b8f7418ac38',
    'Accept': 'application/json'    
}
 
response = requests.post('https://westus.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language=zh-CN', headers=headers, verify=False, data=saf()
                         )
 
print(response.content)
results=json.loads(response.content)
print(results["DisplayText"])
