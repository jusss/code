import json
def get_location(_dict):
    print("searching location")
    _dict = json.loads(_dict)
    loc = _dict["location"]
    return "not implemented yet"

