import json
def get_location(_dict):
    _dict = json.loads(_dict)
    loc = _dict["location"]
    return "not implemented yet"

