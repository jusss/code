import json
from datetime import datetime

def get_time(_str):
    current_time = datetime.now()
    return str(current_time)

