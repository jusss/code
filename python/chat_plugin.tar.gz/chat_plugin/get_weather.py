import json, requests
# curl wttr.in/Detroit?format=j1
def get_weather(_dict):
    # return "Sunny"
    try:

        _dict = json.loads(_dict)
        loc = _dict["location"]
    
        url = f"https://wttr.in/{loc}"
        # params = {"format": "j1"}
        headers = {
            'Content-Type': 'application/json'
        }
    
        # with requests.get(url, headers = headers, params=params) as response:
        with requests.get(url, headers = headers) as response:
            return response.text
            # r=response.json()
            # r=response.text
            # print(r)
            # v = r["current_condition"][0]["weatherDesc"][0]["value"]
            # print(v)
        # return loc + " is " + v
    except:
        return loc + " weather is unknown"



#r=get_weather('{"location":"Beijing, China"}')
#print(r)
