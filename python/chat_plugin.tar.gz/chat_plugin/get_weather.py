import json, requests
# curl wttr.in/Detroit?format=j1
# curl "wttr.in/Beijing?format=j2"
def get_weather(_dict):
    # return "Sunny"
    try:

        _dict = json.loads(_dict)
        loc = _dict["location"]
        print(f"searching weather of {loc}")
    
        url = f"https://wttr.in/{loc}"
        params = {"format": "j2"}
        headers = {
            'Content-Type': 'application/json'
        }
    
        # with requests.get(url, headers = headers, params=params) as response:
        with requests.get(url, headers = headers, params=params) as response:
            # print(response.text)
            # return response.text
            r=response.json()
            # print(r["current_condition"])
            return json.dumps(r["current_condition"])
            # r=response.text
            # print(r)
            # v = r["current_condition"][0]["weatherDesc"][0]["value"]
            # print(v)
        # return loc + " is " + v
    except Exception as e:
        print(e)
        return loc + " weather is unknown"



#r=get_weather('{"location":"Beijing, China"}')
#print(r)
