import requests, json

def web_search(query):
    
    _dict = json.loads(query)
    search_term = _dict["query"]

    api_key = ""
    # search_term = 'puppies'
    
    # Define the endpoint and parameters
    url = 'https://api.bing.microsoft.com/v7.0/search'
    headers = {'Ocp-Apim-Subscription-Key': api_key}
    params = {'q': search_term}
    
    # Make the request
    response = requests.get(url, headers=headers, params=params)
    
    # Check if request was successful
    if response.status_code == 200:
        data = response.json()
        #print(data)
        snippets = [d['snippet'] for d in data['webPages']['value']]
        result = "\n".join(snippets)
        #print(result)
        return result
        # Print the response data (or handle it as needed)
        # print(data)
        # return response.text
    else:
        # print("Error:", response.status_code, response.text)
        return "not found"


#web_search('{"query": "Donald Trump"}')
