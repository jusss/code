import requests, json
from itertools import accumulate

def web_search(query):

    def trim_web(alist, length):
        # [1,2,3,4,5] 5
        # [1,3,6]
        d = list(map(lambda xs: len(json.dumps(xs,ensure_ascii=False).encode('utf8')), alist))
        for n, r in enumerate(accumulate(d)):
            if r > length:
                if n == 0:
                    return []
                else:
                    return alist[:n]
    
        return alist
    
    _dict = json.loads(query)
    search_term = _dict["query"]

    print(f"searching web for {search_term}")
    api_key = ""
    # search_term = 'puppies'
    
    # Define the endpoint and parameters
    url = 'https://api.bing.microsoft.com/v7.0/search'
    headers = {'Ocp-Apim-Subscription-Key': api_key}
    params = {'q': search_term}
    
    # Make the request
    response = requests.get(url, headers=headers, params=params)
    
    # Check if request was successful
    if response.status_code == 200:
        data = response.json()
        #print(data)
        snippets = [d['snippet'] for d in data['webPages']['value']]
        # ori = "\n".join(snippets)
        # print(f"the result length is {len(ori)}")
        snippets = trim_web(snippets, 16000)
        result = "\n".join(snippets)
        # print(result)
        # print(f"after trim, result length is {len(result)}")
        return result
        # Print the response data (or handle it as needed)
        # print(data)
        # return response.text
    else:
        # print("Error:", response.status_code, response.text)
        print("not found")
        return "not found"


#web_search('{"query": "Donald Trump"}')
