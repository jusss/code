import requests, json
#api_key and api_secret are from faceplusplus
files = {
    'api_key': (None, 'x'),
    'api_secret': (None, 'x'),
    'image_file1': ('01.png', open('01.png', 'rb')),
    'image_file2': ('02.png', open('02.png', 'rb')),
}

response = requests.post('https://api-cn.faceplusplus.com/facepp/v3/compare', files=files)

confidence = json.loads(response.content).get("confidence", False)

def getResult(str):
    if not str:
        return "recv nothing!"
    return "pass" if int(confidence) >= 80 else "not pass"

print(getResult(confidence))

print(confidence)
