write your words into Reader.txt with UTF-8 encoding, and file your APPID and API_KEY in the test_webtts.py
you can get them from https://console.xfyun.cn/services/online_tts 
and remember to register your ip into white-list when you use web_api way, the output is in audio directory